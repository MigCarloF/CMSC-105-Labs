package sample;

import java.util.ArrayList;

public class Stratified implements Sampler {
	private ArrayList<Data> sample;

	@Override
	public ArrayList<Data> sample(ArrayList<Data> population, int amount) {
		// TODO Auto-generated method stub
		return null;
	}
}
