package sample;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;

public class SamplerTest {

	public static void main(String[] args) {
		new SamplerControl();
	}
}
